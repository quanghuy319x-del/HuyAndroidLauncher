package dev.glasshome.launcher;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.os.Build;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Glass Home — dependency-free, native Android home-screen replacement.
 * All installed launchable apps are on home pages; there is no app drawer.
 */
public class MainActivity extends Activity {
    private static final String PREF_NAME = "glass_home_v1";
    private static final int WIDGET_HOST_ID = 7023;
    private static final int REQUEST_BIND_WIDGET = 712;
    private static final int REQUEST_CONFIG_WIDGET = 713;
    private AppWidgetManager widgetManager;
    private AppWidgetHost widgetHost;
    private int pendingWidgetId = -1;
    private final ArrayList<Placement> placements = new ArrayList<>();
    private Runnable pendingEdgeAction;
    private int edgeTarget = -1;
    private static final String KEY_HOME = "home";
    private static final String KEY_DOCK = "dock";
    private final LinkedHashMap<String, ResolveInfo> installed = new LinkedHashMap<>();
    private final ArrayList<Item> home = new ArrayList<>();
    private final ArrayList<String> dock = new ArrayList<>();
    private final ArrayList<View> liveTiles = new ArrayList<>();
    private final ArrayList<View> pageViews = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private SharedPreferences prefs;
    private FrameLayout root;
    private LinearLayout body;
    private BackdropView backdrop;
    private SnapPages pages;
    private LinearLayout dotBar;
    private TextView doneButton;
    private boolean editing = false;
    private boolean reduceMotion = false;
    private int columns = 4;
    private int rows = 5;
    private String labelFont = "Google Sans Medium";
    private int labelSizeSp = 15;
    private boolean showSearchBar = true;
    private int homeTileHeightPx = 0;
    private int pageCapacity = 20;
    private int currentPage = 0;
    private int palette = 3;
    private boolean rebuilding = false;
    private String installedSignature = "";

    private static class Item {
        String id;
        String name;
        int spanX = 1, spanY = 1;
        final ArrayList<String> children = new ArrayList<>();
        Item(String component) { id = component; }
        static Item folder(String title) {
            Item item = new Item("folder:" + UUID.randomUUID());
            item.name = title;
            return item;
        }
        boolean isFolder() { return id.startsWith("folder:"); }
        boolean isWidget() { return id.startsWith("widget:"); }
        int widgetId() {
            try { return Integer.parseInt(id.substring(7)); }
            catch (Exception ignored) { return -1; }
        }
    }
    private static class Placement {
        Item item;
        int page, row, col, index;
        Placement(Item item, int page, int row, int col, int index) {
            this.item=item; this.page=page; this.row=row; this.col=col; this.index=index;
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        widgetManager = AppWidgetManager.getInstance(this);
        widgetHost = new AppWidgetHost(this, WIDGET_HOST_ID);
        loadPreferences();
        loadInstalledApps();
        restoreLayout();
        refreshScreen();
        if (!prefs.getBoolean("welcome_seen", false)) {
            prefs.edit().putBoolean("welcome_seen", true).apply();
            handler.postDelayed(this::showWelcome, 550);
        }
    }

    @Override protected void onStart() {
        super.onStart();
        if (widgetHost != null) {
            try { widgetHost.startListening(); } catch (Exception ignored) { }
        }
    }

    @Override protected void onStop() {
        if (widgetHost != null) widgetHost.stopListening();
        super.onStop();
    }

    @Override protected void onResume() {
        super.onResume();
        if (prefs == null) return;
        String previous = installedSignature;
        loadInstalledApps();
        if (!previous.equals(installedSignature) && !rebuilding) {
            reconcileApps();
            refreshScreen();
        }
    }

    @Override public void onBackPressed() {
        if (editing) { changeEditing(false); return; }
        if (currentPage != 0 && pages != null) { pages.goToPage(0, true); return; }
        // A HOME app should stay on the home screen when Back is pressed.
    }

    private void loadPreferences() {
        columns = prefs.getInt("columns", 4);
        columns = Math.max(3, Math.min(6, columns));
        rows = Math.max(3, Math.min(12, prefs.getInt("rows", 5)));
        labelFont = prefs.getString("label_font", "Google Sans Medium");
        labelSizeSp = Math.max(8, Math.min(24, prefs.getInt("label_size", 15)));
        showSearchBar = prefs.getBoolean("show_search_bar", true);
        palette = prefs.getInt("palette", 3);
        reduceMotion = prefs.getBoolean("reduce_motion", false);
    }

    private void loadInstalledApps() {
        installed.clear();
        Intent query = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        List<ResolveInfo> results = pm.queryIntentActivities(query, 0);
        results.sort(Comparator.comparing(r -> String.valueOf(r.loadLabel(pm)), String.CASE_INSENSITIVE_ORDER));
        for (ResolveInfo r : results) {
            if (r.activityInfo == null || getPackageName().equals(r.activityInfo.packageName)) continue;
            ComponentName component = new ComponentName(r.activityInfo.packageName, r.activityInfo.name);
            installed.put(component.flattenToString(), r);
        }
        ArrayList<String> keys = new ArrayList<>(installed.keySet());
        Collections.sort(keys);
        installedSignature = TextUtils.join("|", keys);
    }

    private void restoreLayout() {
        home.clear(); dock.clear();
        if (!prefs.contains(KEY_HOME)) {
            for (String id : installed.keySet()) home.add(new Item(id));
            chooseInitialDock();
        } else {
            try {
                JSONArray array = new JSONArray(prefs.getString(KEY_HOME, "[]"));
                for (int i = 0; i < array.length(); i++) {
                    JSONObject obj = array.optJSONObject(i);
                    if (obj == null) continue;
                    if (obj.has("widget")) {
                        int widgetId = obj.optInt("widget", -1);
                        if (widgetId >= 0) {
                            Item widget = new Item("widget:" + widgetId);
                            widget.spanX = Math.max(1, obj.optInt("x", 2));
                            widget.spanY = Math.max(1, obj.optInt("y", 2));
                            home.add(widget);
                        }
                    } else if (obj.has("app")) {
                        String id = obj.optString("app");
                        if (!id.isEmpty()) home.add(new Item(id));
                    } else if (obj.has("folder")) {
                        Item item = new Item(obj.optString("folder"));
                        item.name = obj.optString("name", "Folder");
                        JSONArray children = obj.optJSONArray("apps");
                        if (children != null) for (int j = 0; j < children.length(); j++) {
                            item.children.add(children.optString(j));
                        }
                        home.add(item);
                    }
                }
                JSONArray dockArray = new JSONArray(prefs.getString(KEY_DOCK, "[]"));
                for (int i = 0; i < dockArray.length(); i++) dock.add(dockArray.optString(i));
            } catch (JSONException error) {
                home.clear(); dock.clear();
            }
            if (home.isEmpty() && dock.isEmpty()) {
                for (String id : installed.keySet()) home.add(new Item(id));
                chooseInitialDock();
            }
        }
        reconcileApps();
    }

    private void chooseInitialDock() {
        // Prefer the user's installed phone, messages, browser, and camera applications.
        String[] patterns = {"dialer", "phone", "messag", "chrome", "browser", "camera"};
        for (String pattern : patterns) {
            if (dock.size() == 4) break;
            for (String id : installed.keySet()) {
                String lower = id.toLowerCase(Locale.ROOT);
                if (lower.contains(pattern) && !dock.contains(id)) {
                    dock.add(id);
                    break;
                }
            }
        }
        for (String id : installed.keySet()) {
            if (dock.size() == 4) break;
            if (!dock.contains(id)) dock.add(id);
        }
        for (String id : dock) removeHomeApp(id);
    }

    private void reconcileApps() {
        Set<String> seen = new HashSet<>();
        dock.removeIf(id -> !installed.containsKey(id) || !seen.add(id));
        ArrayList<Item> remove = new ArrayList<>();
        for (Item item : home) {
            if (item.isWidget()) {
                if (widgetManager.getAppWidgetInfo(item.widgetId()) == null) remove.add(item);
            } else if (item.isFolder()) {
                item.children.removeIf(id -> !installed.containsKey(id) || !seen.add(id));
                if (item.children.isEmpty()) remove.add(item);
            } else if (!installed.containsKey(item.id) || !seen.add(item.id)) {
                remove.add(item);
            }
        }
        home.removeAll(remove);
        for (String id : installed.keySet()) {
            if (!seen.contains(id)) { home.add(new Item(id)); seen.add(id); }
        }
        saveLayout();
    }

    private void saveLayout() {
        JSONArray homeJson = new JSONArray();
        for (Item item : home) {
            JSONObject obj = new JSONObject();
            try {
                if (item.isWidget()) {
                    obj.put("widget", item.widgetId());
                    obj.put("x", item.spanX);
                    obj.put("y", item.spanY);
                } else if (item.isFolder()) {
                    obj.put("folder", item.id);
                    obj.put("name", item.name);
                    obj.put("apps", new JSONArray(item.children));
                } else obj.put("app", item.id);
                homeJson.put(obj);
            } catch (JSONException ignored) { }
        }
        prefs.edit().putString(KEY_HOME, homeJson.toString())
                .putString(KEY_DOCK, new JSONArray(dock).toString()).apply();
    }

    private int dp(float number) {
        return (int) (number * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int fill, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private GradientDrawable glass(float radius, boolean strong) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                strong ? new int[]{0x70FFFFFF, 0x24FFFFFF} : new int[]{0x52FFFFFF, 0x10FFFFFF});
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), strong ? 0x75FFFFFF : 0x45FFFFFF);
        return d;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(sp);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        return t;
    }

    private static final String[] FONT_NAMES = {
            "Google Sans Medium", "Google Sans", "Google Sans Flex", "Roboto", "Roboto Medium",
            "Samsung One", "Noto Sans", "Sans Serif", "Serif", "Monospace", "Condensed"
    };

    private Typeface labelTypeface() {
        String family;
        switch (labelFont) {
            case "Google Sans Medium": family = android.os.Build.MANUFACTURER.equalsIgnoreCase("Google")
                    ? "google-sans-medium" : "sans-serif-medium"; break;
            case "Google Sans": family = "google-sans"; break;
            case "Google Sans Flex": family = "google-sans-flex"; break;
            case "Roboto": family = "sans-serif"; break;
            case "Roboto Medium": family = "sans-serif-medium"; break;
            case "Samsung One": family = "samsungone"; break;
            case "Noto Sans": family = "sans-serif"; break;
            case "Serif": family = "serif"; break;
            case "Monospace": family = "monospace"; break;
            case "Condensed": family = "sans-serif-condensed"; break;
            default: family = "sans-serif";
        }
        return Typeface.create(family, Typeface.NORMAL);
    }

    private void showFontSettings() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(10), dp(20), 0);
        TextView caption = text("App label font", 15, Color.DKGRAY, true);
        panel.addView(caption, new LinearLayout.LayoutParams(-1, dp(42)));
        android.widget.Spinner fontPicker = new android.widget.Spinner(this);
        android.widget.ArrayAdapter<String> adapter = new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, FONT_NAMES);
        fontPicker.setAdapter(adapter);
        int fontIndex = java.util.Arrays.asList(FONT_NAMES).indexOf(labelFont);
        fontPicker.setSelection(Math.max(0, fontIndex));
        panel.addView(fontPicker, new LinearLayout.LayoutParams(-1, dp(48)));
        TextView captionSize = text("Label size: " + labelSizeSp + " sp", 15, Color.DKGRAY, false);
        panel.addView(captionSize, new LinearLayout.LayoutParams(-1, dp(42)));
        android.widget.SeekBar sizePicker = new android.widget.SeekBar(this);
        sizePicker.setMax(16); // 8–24 sp
        sizePicker.setProgress(labelSizeSp - 8);
        sizePicker.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
                captionSize.setText("Label size: " + (8 + progress) + " sp");
            }
            @Override public void onStartTrackingTouch(android.widget.SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(android.widget.SeekBar seekBar) {}
        });
        panel.addView(sizePicker, new LinearLayout.LayoutParams(-1, dp(54)));
        new AlertDialog.Builder(this).setTitle("App label typography")
                .setView(panel)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Apply", (d, which) -> {
                    labelFont = FONT_NAMES[fontPicker.getSelectedItemPosition()];
                    labelSizeSp = 8 + sizePicker.getProgress();
                    prefs.edit().putString("label_font", labelFont)
                            .putInt("label_size", labelSizeSp).apply();
                    refreshScreen();
                }).show();
    }

    private void refreshScreen() {
        rebuilding = true;
        int pageToRestore = currentPage;
        cancelEdgeHover();
        for (View old : liveTiles) {
            Object animation = old.getTag();
            if (animation instanceof ObjectAnimator) ((ObjectAnimator) animation).cancel();
            old.animate().cancel();
        }
        liveTiles.clear(); pageViews.clear();
        if (root == null) { root = new FrameLayout(this); setContentView(root); }
        root.removeAllViews();
        backdrop = new BackdropView(this);
        root.addView(backdrop, new FrameLayout.LayoutParams(-1, -1));
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        root.addView(body, new FrameLayout.LayoutParams(-1, -1));
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            body.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
            return insets;
        });
        root.requestApplyInsets();
        buildHeader();
        float heightDp = getResources().getDisplayMetrics().heightPixels /
                getResources().getDisplayMetrics().density;
        int availableDp = (int) heightDp - 46 - 62 - 30 - 92 - (showSearchBar ? 64 : 0);
        homeTileHeightPx = dp(Math.max(68, availableDp / rows));
        pageCapacity = columns * rows;
        buildPages();
        buildDots();
        buildDock();
        if (pages != null) {
            currentPage = Math.min(pageToRestore, Math.max(0, pageViews.size() - 1));
            int pageWidth = getResources().getDisplayMetrics().widthPixels;
            pages.post(() -> { if (pages != null) pages.scrollTo(currentPage * pageWidth, 0); updateDots(); });
        }
        rebuilding = false;
    }

    private void buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(24), dp(14), dp(24), 0);
        body.addView(header, new LinearLayout.LayoutParams(-1, dp(62)));
        // Pixel-style At a Glance: clean date, not a fabricated weather display.
        TextView date = text(new SimpleDateFormat("EEE, MMM d", Locale.getDefault())
                .format(Calendar.getInstance().getTime()), 16, Color.WHITE, true);
        date.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        date.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        date.setShadowLayer(dp(3), 0, dp(1), 0xBB000000);
        header.addView(date, new LinearLayout.LayoutParams(-1, dp(46)));
        date.setOnLongClickListener(v -> { showHomeOptions(); return true; });
    }

    private void showHomeOptions() {
        new AlertDialog.Builder(this).setTitle("Home screen")
                .setItems(new String[]{"Widgets", "Wallpaper & style", "Home settings", "Edit layout"},
                        (dialog, which) -> {
                            if (which == 0) showWidgetPicker();
                            else if (which == 1) {
                                try { startActivity(new Intent(Intent.ACTION_SET_WALLPAPER)); }
                                catch (Exception e) { toast("Wallpaper settings unavailable"); }
                            } else if (which == 2) showSettings();
                            else changeEditing(true);
                        }).show();
    }

    private boolean fits(boolean[][] used, int row, int col, int sx, int sy) {
        if (col + sx > columns || row + sy > rows) return false;
        for (int y=row; y<row+sy; y++) for (int x=col; x<col+sx; x++)
            if (used[y][x]) return false;
        return true;
    }

    private int calculatePlacements() {
        placements.clear();
        ArrayList<boolean[][]> occupancy = new ArrayList<>();
        occupancy.add(new boolean[rows][columns]);
        int page=0;
        for (int index=0; index<home.size(); index++) {
            Item item=home.get(index);
            int sx = item.isWidget() ? Math.max(1, Math.min(columns, item.spanX)) : 1;
            int sy = item.isWidget() ? Math.max(1, Math.min(rows, item.spanY)) : 1;
            boolean placed=false;
            while (!placed) {
                while (occupancy.size()<=page) occupancy.add(new boolean[rows][columns]);
                boolean[][] used=occupancy.get(page);
                for (int y=0; y<rows && !placed; y++) for (int x=0; x<columns && !placed; x++) {
                    if (!fits(used,y,x,sx,sy)) continue;
                    for (int j=y;j<y+sy;j++) for (int i=x;i<x+sx;i++) used[j][i]=true;
                    placements.add(new Placement(item,page,y,x,index));
                    placed=true;
                }
                if (!placed) page++;
            }
        }
        return occupancy.size();
    }

    private void buildPages() {
        pages = new SnapPages(this);
        pages.setFillViewport(false);
        pages.setHorizontalScrollBarEnabled(false);
        pages.setOverScrollMode(View.OVER_SCROLL_NEVER);
        body.addView(pages, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout strip = new LinearLayout(this);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        pages.addView(strip, new ViewGroup.LayoutParams(-2, -1));
        int pageCount = calculatePlacements();
        int count = Math.max(1, pageCount + (editing ? 1 : 0));
        int pageWidth = getResources().getDisplayMetrics().widthPixels;
        int tileWidth = (pageWidth - dp(24)) / columns;
        for (int pageIndex=0; pageIndex<count; pageIndex++) {
            FrameLayout page = new FrameLayout(this);
            strip.addView(page, new LinearLayout.LayoutParams(pageWidth, -1));
            pageViews.add(page);
            GridLayout grid = new GridLayout(this);
            grid.setColumnCount(columns);
            grid.setRowCount(rows);
            grid.setPadding(dp(12), dp(6), dp(12), dp(8));
            ScrollView vertical = new ScrollView(this);
            vertical.setFillViewport(true);
            vertical.setVerticalScrollBarEnabled(false);
            page.addView(vertical, new FrameLayout.LayoutParams(-1, -1));
            vertical.addView(grid, new ScrollView.LayoutParams(-1, -2));
            for (Placement placement : placements) {
                if (placement.page != pageIndex) continue;
                Item item=placement.item;
                View tile=item.isWidget() ? buildWidgetTile(item, tileWidth) : buildTile(item, false, tileWidth);
                int sx=item.isWidget() ? Math.min(columns, item.spanX) : 1;
                int sy=item.isWidget() ? Math.min(rows, item.spanY) : 1;
                GridLayout.LayoutParams lp=new GridLayout.LayoutParams(
                        GridLayout.spec(placement.row,sy),GridLayout.spec(placement.col,sx));
                lp.width=tileWidth*sx;
                lp.height=homeTileHeightPx*sy;
                grid.addView(tile,lp);
            }
            final int targetPage=pageIndex;
            grid.setOnLongClickListener(v -> { showHomeOptions(); return true; });
            page.setOnLongClickListener(v -> { showHomeOptions(); return true; });
            grid.setOnDragListener((view,event)->{
                if (event.getAction()==DragEvent.ACTION_DRAG_STARTED) return true;
                if (event.getAction()==DragEvent.ACTION_DRAG_LOCATION) {
                    trackEdgeHover(view,event); return true;
                }
                if (event.getAction()==DragEvent.ACTION_DROP) {
                    cancelEdgeHover();
                    String key=readDrag(event);
                    if(key!=null) moveToPage(key,targetPage);
                    return true;
                }
                if (event.getAction()==DragEvent.ACTION_DRAG_ENDED) cancelEdgeHover();
                return true;
            });
        }
    }

    private void trackEdgeHover(View view, DragEvent event) {
        if (pages == null || pageViews.size() < 2) return;
        int[] loc=new int[2]; view.getLocationOnScreen(loc);
        int globalX=loc[0]+(int)event.getX();
        int width=getResources().getDisplayMetrics().widthPixels;
        int dest=globalX < dp(35) ? currentPage-1 : globalX > width-dp(35) ? currentPage+1 : -1;
        if (dest == edgeTarget) return;
        cancelEdgeHover();
        if (dest < 0 || dest >= pageViews.size()) return;
        edgeTarget=dest;
        final int finalDest=dest;
        pendingEdgeAction=()->{ if (pages != null) pages.goToPage(finalDest,true); edgeTarget=-1; };
        handler.postDelayed(pendingEdgeAction,700);
    }
    private void cancelEdgeHover() {
        if (pendingEdgeAction!=null) handler.removeCallbacks(pendingEdgeAction);
        pendingEdgeAction=null;
        edgeTarget=-1;
    }

    private View buildWidgetTile(Item item, int cellWidth) {
        FrameLayout container=new FrameLayout(this);
        container.setPadding(dp(3),dp(3),dp(3),dp(3));
        try {
            AppWidgetProviderInfo info=widgetManager.getAppWidgetInfo(item.widgetId());
            if (info == null) return container;
            AppWidgetHostView widget=widgetHost.createView(this,item.widgetId(),info);
            widget.setAppWidget(item.widgetId(),info);
            container.addView(widget,new FrameLayout.LayoutParams(-1,-1));
            // Widget contents stay interactive; long-press on a border opens resize/remove.
            container.setOnLongClickListener(v->{ showWidgetActions(item); return true; });
            View handle=new View(this);
            handle.setBackground(rounded(0x33000000,6));
            FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(16),dp(16),Gravity.TOP|Gravity.END);
            hp.topMargin=dp(2);hp.rightMargin=dp(2);
            container.addView(handle,hp);
            handle.setOnLongClickListener(v->{showWidgetActions(item);return true;});
            handle.setOnClickListener(v->showWidgetActions(item));
        } catch (Exception e) { container.setOnClickListener(v->showWidgetActions(item)); }
        return container;
    }

    private void buildDots() {
        dotBar = new LinearLayout(this);
        dotBar.setGravity(Gravity.CENTER);
        body.addView(dotBar, new LinearLayout.LayoutParams(-1, dp(30)));
        updateDots();
    }

    private void updateDots() {
        if (dotBar == null) return;
        dotBar.removeAllViews();
        int count = pageViews.size();
        if (count > 10) {
            TextView counter = text((currentPage + 1) + " / " + count, 12, Color.WHITE, false);
            dotBar.addView(counter);
            return;
        }
        for (int i = 0; i < count; i++) {
            final int target = i;
            View dot = new View(this);
            dot.setBackground(rounded(i == currentPage ? 0xFFFFFFFF : 0x75FFFFFF, 10));
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(6), dp(6));
            dlp.setMargins(dp(4), 0, dp(4), 0);
            dotBar.addView(dot, dlp);
            dot.setOnClickListener(v -> pages.goToPage(target, true));
        }
    }

    private void buildDock() {
        LinearLayout outer=new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(16),0,dp(16),dp(6));
        body.addView(outer,new LinearLayout.LayoutParams(-1,dp(showSearchBar?150:92)));
        LinearLayout favorites=new LinearLayout(this);
        favorites.setGravity(Gravity.CENTER);
        outer.addView(favorites,new LinearLayout.LayoutParams(-1,dp(82)));
        int width=(getResources().getDisplayMetrics().widthPixels-dp(32))/5;
        for (String id:dock) {
            View tile=buildTile(new Item(id),true,width);
            favorites.addView(tile,new LinearLayout.LayoutParams(0,dp(82),1));
        }
        // Blank dock area is a native entry point to the Pixel-style Home options.
        favorites.setOnLongClickListener(v->{showHomeOptions();return true;});
        if (showSearchBar) {
            TextView search=text("G    Search your apps                 ◉",14,Color.WHITE,false);
            search.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
            search.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
            search.setPadding(dp(19),0,dp(12),0);
            search.setBackground(rounded(0xBD263138,32));
            LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,dp(50));
            params.topMargin=dp(5);
            outer.addView(search,params);
            search.setOnClickListener(v->showSearch());
            search.setOnLongClickListener(v->{showHomeOptions();return true;});
        }
    }

    private View buildTile(Item item, boolean inDock, int widthPx) {
        final String key = (inDock ? "dock:" : "home:") + item.id;
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        tile.setPadding(dp(2), dp(inDock ? 8 : 10), dp(2), 0);
        tile.setClipChildren(false);
        tile.setClipToPadding(false);
        liveTiles.add(tile);
        int maxIconDp = inDock ? 60 : (columns >= 6 ? 43 : columns == 5 ? 52 : columns == 3 ? 65 : 60);
        int iconSize = inDock ? dp(60) : Math.max(dp(28), Math.min(dp(maxIconDp), homeTileHeightPx - dp(30)));
        FrameLayout iconBox = new FrameLayout(this);
        tile.addView(iconBox, new LinearLayout.LayoutParams(iconSize, iconSize));

        if (item.isFolder()) {
            iconBox.setBackground(rounded(0xAA616873, 23));
            GridLayout preview = new GridLayout(this);
            preview.setColumnCount(3); preview.setRowCount(3);
            int previewPad = Math.max(dp(3), iconSize / 10);
            preview.setPadding(previewPad, previewPad, previewPad, previewPad);
            iconBox.addView(preview, new FrameLayout.LayoutParams(-1, -1));
            for (int i = 0; i < Math.min(9, item.children.size()); i++) {
                ImageView mini = new ImageView(this);
                setAppIcon(mini, item.children.get(i));
                GridLayout.LayoutParams mp = new GridLayout.LayoutParams(
                        GridLayout.spec(i / 3), GridLayout.spec(i % 3));
                mp.width = (iconSize - previewPad * 2) / 3;
                mp.height = (iconSize - previewPad * 2) / 3;
                preview.addView(mini, mp);
            }
        } else {
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.FIT_CENTER);
            image.setBackground(rounded(0x10000000, 100));
            image.setClipToOutline(true);
            setAppIcon(image, item.id);
            image.setClipToOutline(true);
            iconBox.addView(image, new FrameLayout.LayoutParams(-1, -1));
        }
        TextView label = text(item.isFolder() ? item.name : appName(item.id), labelSizeSp, Color.WHITE, false);
        label.setTypeface(labelTypeface());
        label.setSingleLine(true);
        label.setEllipsize(TextUtils.TruncateAt.END);
        label.setShadowLayer(dp(3), 0, dp(1), 0xB9000000);
        if (!inDock) {
            LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(-1, dp(28));
            labelParams.topMargin = dp(homeTileHeightPx < dp(73) ? 2 : 5);
            tile.addView(label, labelParams);
        }
        tile.setContentDescription(item.isFolder() ? "Folder " + item.name : appName(item.id));

        tile.setOnClickListener(v -> {
            if (editing) showItemActions(key);
            else if (item.isFolder()) openFolder(item);
            else activateApp(tile, item.id);
        });
        tile.setOnLongClickListener(v -> {
            if (!editing) changeEditingWithoutRebuild(true);
            ClipData data = ClipData.newPlainText("launcher-id", key);
            View.DragShadowBuilder shadow = new View.DragShadowBuilder(iconBox);
            tile.startDragAndDrop(data, shadow, null, 0);
            return true;
        });
        tile.setOnTouchListener((v, event) -> {
            if (editing || reduceMotion) return false;
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(85).start();
            } else if (event.getActionMasked() == MotionEvent.ACTION_UP ||
                    event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                v.animate().scaleX(1f).scaleY(1f).setDuration(220)
                        .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
            }
            return false;
        });
        tile.setOnDragListener((view, event) -> {
            if (event.getAction() == DragEvent.ACTION_DRAG_STARTED) return true;
            if (event.getAction() == DragEvent.ACTION_DRAG_LOCATION) trackEdgeHover(view,event);
            if (event.getAction() == DragEvent.ACTION_DRAG_ENTERED) {
                view.animate().scaleX(1.09f).scaleY(1.09f).setDuration(100).start();
            } else if (event.getAction() == DragEvent.ACTION_DRAG_EXITED ||
                    event.getAction() == DragEvent.ACTION_DRAG_ENDED) {
                view.animate().scaleX(1f).scaleY(1f).setDuration(130).start();
            } else if (event.getAction() == DragEvent.ACTION_DROP) {
                view.animate().scaleX(1f).scaleY(1f).setDuration(130).start();
                String dragged = readDrag(event);
                if (dragged != null) dropOnTile(dragged, key);
                return true;
            }
            return true;
        });
        return tile;
    }

    private String readDrag(DragEvent event) {
        ClipData data = event.getClipData();
        return data == null || data.getItemCount() == 0 ? null :
                String.valueOf(data.getItemAt(0).coerceToText(this));
    }

    private void setAppIcon(ImageView image, String id) {
        ResolveInfo info = installed.get(id);
        if (info == null) return;
        try { image.setImageDrawable(info.loadIcon(getPackageManager())); }
        catch (Exception ignored) { }
    }

    private String appName(String id) {
        ResolveInfo info = installed.get(id);
        return info == null ? "App" : String.valueOf(info.loadLabel(getPackageManager()));
    }

    private void activateApp(View tile, String id) {
        if (!installed.containsKey(id)) return;
        Runnable launch = () -> {
            ComponentName component = ComponentName.unflattenFromString(id);
            if (component == null) return;
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            intent.setComponent(component);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            try { startActivity(intent); }
            catch (Exception e) { Toast.makeText(this, "Couldn't open app", Toast.LENGTH_SHORT).show(); }
        };
        if (reduceMotion) launch.run();
        else tile.animate().scaleX(1.13f).scaleY(1.13f).alpha(0.72f).setDuration(120)
                .withEndAction(() -> {
                    launch.run();
                    tile.animate().scaleX(1f).scaleY(1f).alpha(1f)
                            .setDuration(220).setInterpolator(new OvershootInterpolator()).start();
                }).start();
    }

    private void changeEditing(boolean enabled) {
        editing = enabled;
        refreshScreen();
    }

    private void changeEditingWithoutRebuild(boolean enabled) {
        editing = enabled;
        if (doneButton != null) doneButton.setText(enabled ? "Done" : "Edit");
        animateEditTiles(enabled);
    }

    private void animateEditTiles(boolean enabled) {
        // Pixel Launcher uses a stationary home screen rather than iOS wiggle mode.
        for (View tile : liveTiles) {
            Object animation=tile.getTag();
            if(animation instanceof ObjectAnimator) ((ObjectAnimator)animation).cancel();
            tile.setRotation(0f);
            tile.setTag(null);
        }
    }

    private int homeIndex(String key) {
        if (key == null || !key.startsWith("home:")) return -1;
        String id = key.substring(5);
        for (int i = 0; i < home.size(); i++) if (home.get(i).id.equals(id)) return i;
        return -1;
    }

    private int dockIndex(String key) {
        if (key == null || !key.startsWith("dock:")) return -1;
        return dock.indexOf(key.substring(5));
    }

    private void dropOnTile(String from, String target) {
        if (from.equals(target)) return;
        int sourceHome=homeIndex(from),targetHome=homeIndex(target);
        int sourceDock=dockIndex(from),targetDock=dockIndex(target);
        if (sourceHome>=0 && targetHome>=0) {
            Item a=home.get(sourceHome),b=home.get(targetHome);
            if (!a.isFolder() && !a.isWidget() && !b.isWidget()) {
                if (b.isFolder()) {
                    if (!b.children.contains(a.id)) b.children.add(a.id);
                    home.remove(a);
                } else {
                    Item folder=Item.folder("Folder");
                    folder.children.add(b.id);
                    folder.children.add(a.id);
                    home.set(targetHome,folder);
                    home.remove(a);
                }
            } else {
                home.remove(a);
                int insertion=home.indexOf(b);
                home.add(Math.max(0,insertion),a);
            }
        } else if (sourceDock>=0 && targetDock>=0) {
            Collections.swap(dock,sourceDock,targetDock);
        } else if (sourceHome>=0 && targetDock>=0) {
            Item a=home.get(sourceHome);
            if(a.isWidget() || a.isFolder()) {toast("Only apps can go in the dock");return;}
            home.remove(sourceHome);
            String moved=dock.set(targetDock,a.id);
            home.add(Math.min(sourceHome,home.size()),new Item(moved));
        } else if (sourceDock>=0 && targetHome>=0) {
            Item b=home.get(targetHome);
            String dragged=dock.get(sourceDock);
            if (b.isFolder()) {
                if (!b.children.contains(dragged)) b.children.add(dragged);
                dock.remove(sourceDock);
            } else if(!b.isWidget()) {
                Item folder=Item.folder("Folder");
                folder.children.add(b.id);folder.children.add(dragged);
                home.set(targetHome,folder);
                dock.remove(sourceDock);
            } else {toast("Drop apps on an app or folder");return;}
        } else return;
        editing=false;
        saveLayout();
        refreshScreen();
    }

    private void moveToPage(String key, int targetPage) {
        int index=homeIndex(key);
        if(index<0)return;
        int insertion=home.size();
        for(Placement p:placements) {
            if(p.page>=targetPage && p.item!=home.get(index)) {insertion=p.index;break;}
        }
        Item removed=home.remove(index);
        if (index<insertion)insertion--;
        home.add(Math.max(0,Math.min(home.size(),insertion)),removed);
        currentPage=targetPage;
        editing=false;
        saveLayout();refreshScreen();
    }

    private void removeHomeApp(String id) {
        for (int i = home.size() - 1; i >= 0; i--)
            if (!home.get(i).isFolder() && home.get(i).id.equals(id)) home.remove(i);
    }

    private void showItemActions(String key) {
        int hi = homeIndex(key), di = dockIndex(key);
        if (hi >= 0) {
            Item item = home.get(hi);
            ArrayList<String> actions = new ArrayList<>(Arrays.asList(
                    "Move one position left", "Move one position right",
                    "Move to previous page", "Move to next page"));
            if (item.isWidget()) {
                actions.add("Resize widget"); actions.add("Remove widget");
            } else if (item.isFolder()) {
                actions.add("Open folder"); actions.add("Rename folder"); actions.add("Ungroup folder");
            } else {
                actions.add("Create folder with this app"); actions.add("App info");
            }
            new AlertDialog.Builder(this).setTitle(item.isFolder() ? item.name : appName(item.id))
                    .setItems(actions.toArray(new String[0]), (dialog, choice) -> {
                        if (choice == 0 || choice == 1) {
                            int other = hi + (choice == 0 ? -1 : 1);
                            if (other < 0 || other >= home.size()) return;
                            Collections.swap(home, hi, other);
                            currentPage = other / pageCapacity;
                            saveLayout(); refreshScreen();
                        } else if (choice == 2 || choice == 3) {
                            int destinationPage = hi / pageCapacity + (choice == 2 ? -1 : 1);
                            if (destinationPage >= 0 && destinationPage < pageViews.size())
                                moveToPage(key, destinationPage);
                            else toast("No page in that direction");
                        } else if (item.isWidget()) {
                            if (choice == 4) resizeWidget(item);
                            if (choice == 5) removeWidget(item);
                        } else if (item.isFolder()) {
                            if (choice == 4) openFolder(item);
                            if (choice == 5) renameFolder(item);
                            if (choice == 6) dissolveFolder(item);
                        } else if (choice == 4) {
                            Item folder = Item.folder("Folder");
                            folder.children.add(item.id);
                            home.set(hi, folder);
                            saveLayout(); refreshScreen();
                            renameFolder(folder);
                        } else if (choice == 5) openAppInfo(item.id);
                    }).setNegativeButton("Cancel", null).show();
        } else if (di >= 0) {
            String id = dock.get(di);
            new AlertDialog.Builder(this).setTitle(appName(id))
                    .setItems(new String[]{"Move left", "Move right", "App info"}, (dialog, choice) -> {
                        if (choice == 2) { openAppInfo(id); return; }
                        int next = di + (choice == 0 ? -1 : 1);
                        if (next >= 0 && next < dock.size()) {
                            Collections.swap(dock, di, next); saveLayout(); refreshScreen();
                        }
                    }).show();
        }
    }

    private void openAppInfo(String id) {
        ComponentName component = ComponentName.unflattenFromString(id);
        if (component == null) return;
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(android.net.Uri.parse("package:" + component.getPackageName()));
        try { startActivity(intent); } catch (Exception ignored) { }
    }

    private void renameFolder(Item item) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(item.name);
        input.selectAll();
        FrameLayout wrapper = new FrameLayout(this);
        wrapper.setPadding(dp(24), 0, dp(24), 0);
        wrapper.addView(input);
        new AlertDialog.Builder(this).setTitle("Folder name").setView(wrapper)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, w) -> {
                    String value = input.getText().toString().trim();
                    item.name = value.isEmpty() ? "Folder" : value;
                    saveLayout(); refreshScreen();
                }).show();
    }

    private void dissolveFolder(Item folder) {
        int index = home.indexOf(folder);
        if (index < 0) return;
        home.remove(index);
        for (int i = 0; i < folder.children.size(); i++)
            home.add(index + i, new Item(folder.children.get(i)));
        saveLayout(); refreshScreen();
    }

    private void openFolder(Item folder) {
        FrameLayout container = new FrameLayout(this);
        container.setPadding(dp(12), dp(12), dp(12), dp(16));
        ScrollView scroll = new ScrollView(this);
        container.addView(scroll, new FrameLayout.LayoutParams(-1, dp(315)));
        GridLayout contents = new GridLayout(this);
        contents.setColumnCount(3);
        contents.setPadding(dp(6), dp(6), dp(6), dp(6));
        scroll.addView(contents);
        int available = getResources().getDisplayMetrics().widthPixels - dp(90);
        int tileWidth = available / 3;
        final AlertDialog[] ref = new AlertDialog[1];
        for (String id : new ArrayList<>(folder.children)) {
            Item child = new Item(id);
            View tile = buildTile(child, false, tileWidth);
            liveTiles.remove(tile); // Dialog tiles must not join the home jiggle animations.
            GridLayout.LayoutParams cp = new GridLayout.LayoutParams();
            cp.width = tileWidth; cp.height = dp(98);
            contents.addView(tile, cp);
            tile.setOnClickListener(v -> { if (ref[0] != null) ref[0].dismiss(); activateApp(tile, id); });
            tile.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this).setTitle(appName(id))
                        .setItems(new String[]{"Move out to Home", "App info"}, (dialog, action) -> {
                            if (action == 0) {
                                folder.children.remove(id);
                                int place = home.indexOf(folder);
                                if (place >= 0) home.add(place + 1, new Item(id));
                                if (folder.children.isEmpty()) home.remove(folder);
                                saveLayout(); if (ref[0] != null) ref[0].dismiss(); refreshScreen();
                            } else openAppInfo(id);
                        }).show();
                return true;
            });
        }
        ref[0] = new AlertDialog.Builder(this).setTitle(folder.name).setView(container)
                .setPositiveButton("Done", null).create();
        ref[0].show();
    }

    // Real Android AppWidgetHost: widgets remain live and interactive on the home screen.
    private void showWidgetPicker() {
        List<AppWidgetProviderInfo> providers=widgetManager.getInstalledProviders();
        if (providers==null || providers.isEmpty()) {toast("No widgets installed");return;}
        providers.sort(Comparator.comparing(x->String.valueOf(x.loadLabel(getPackageManager())),String.CASE_INSENSITIVE_ORDER));
        String[] names=new String[providers.size()];
        for(int i=0;i<providers.size();i++){
            AppWidgetProviderInfo p=providers.get(i);
            names[i]=p.loadLabel(getPackageManager())+"  ·  "+p.provider.getPackageName();
        }
        new AlertDialog.Builder(this).setTitle("Widgets")
                .setItems(names,(d,which)->requestWidget(providers.get(which)))
                .setNegativeButton("Cancel",null).show();
    }

    private void requestWidget(AppWidgetProviderInfo provider) {
        int id=widgetHost.allocateAppWidgetId();
        pendingWidgetId=id;
        try {
            if(widgetManager.bindAppWidgetIdIfAllowed(id,provider.provider)) {
                configureOrAddWidget(id);
            } else {
                Intent bind=new Intent(AppWidgetManager.ACTION_APPWIDGET_BIND);
                bind.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);
                bind.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER,provider.provider);
                startActivityForResult(bind,REQUEST_BIND_WIDGET);
            }
        } catch(Exception e) {
            widgetHost.deleteAppWidgetId(id);
            pendingWidgetId=-1;
            toast("Widget permission unavailable");
        }
    }

    private void configureOrAddWidget(int id) {
        AppWidgetProviderInfo provider=widgetManager.getAppWidgetInfo(id);
        if(provider == null) {forgetPendingWidget(id);return;}
        if(provider.configure!=null) {
            try {
                Intent intent=new Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE);
                intent.setComponent(provider.configure);
                intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);
                startActivityForResult(intent,REQUEST_CONFIG_WIDGET);
                return;
            } catch(Exception ignored) { }
        }
        finishAddWidget(id);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=REQUEST_BIND_WIDGET && requestCode!=REQUEST_CONFIG_WIDGET)return;
        int id=data==null?pendingWidgetId:data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,pendingWidgetId);
        if(resultCode!=RESULT_OK || id<0) {forgetPendingWidget(id);return;}
        if(requestCode==REQUEST_BIND_WIDGET) configureOrAddWidget(id);
        else finishAddWidget(id);
    }

    private void forgetPendingWidget(int id) {
        int toDelete=id>=0?id:pendingWidgetId;
        if (toDelete>=0) try {widgetHost.deleteAppWidgetId(toDelete);}catch(Exception ignored){}
        pendingWidgetId=-1;
    }

    private void finishAddWidget(int id) {
        AppWidgetProviderInfo provider=widgetManager.getAppWidgetInfo(id);
        if(provider==null) {forgetPendingWidget(id);return;}
        pendingWidgetId=-1;
        int cellWidth=Math.max(1,getResources().getDisplayMetrics().widthPixels/columns);
        int spanX=Math.max(1,Math.min(columns,(int)Math.ceil(dp(provider.minWidth)/(double)cellWidth)));
        int spanY=Math.max(1,Math.min(rows,(int)Math.ceil(dp(provider.minHeight)/(double)Math.max(1,homeTileHeightPx))));
        // A useful default size for flexible widgets is at least 2×2.
        spanX=Math.min(columns,Math.max(2,spanX));
        spanY=Math.min(rows,Math.max(2,spanY));
        Item widget=new Item("widget:"+id);
        widget.spanX=spanX;widget.spanY=spanY;
        home.add(widget);
        saveLayout();refreshScreen();
        toast("Widget added · long-press its corner to resize or remove");
    }

    private void showWidgetActions(Item widget) {
        new AlertDialog.Builder(this).setTitle("Widget")
                .setItems(new String[]{"Resize widget", "Remove widget", "Add another widget"},
                        (d,which)->{if(which==0)resizeWidget(widget);else if(which==1)removeWidget(widget);else showWidgetPicker();})
                .show();
    }

    private void resizeWidget(Item widget) {
        LinearLayout panel=new LinearLayout(this);
        panel.setPadding(dp(18),dp(12),dp(18),dp(12));
        panel.setOrientation(LinearLayout.VERTICAL);
        TextView title=text("Width: "+widget.spanX+" columns",15,Color.DKGRAY,false);
        panel.addView(title);
        android.widget.SeekBar width=new android.widget.SeekBar(this);
        width.setMax(columns-1);width.setProgress(Math.min(columns,widget.spanX)-1);
        panel.addView(width);
        TextView heightLabel=text("Height: "+widget.spanY+" rows",15,Color.DKGRAY,false);
        panel.addView(heightLabel);
        android.widget.SeekBar height=new android.widget.SeekBar(this);
        height.setMax(rows-1);height.setProgress(Math.min(rows,widget.spanY)-1);
        panel.addView(height);
        width.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(android.widget.SeekBar b,int p,boolean user){title.setText("Width: "+(p+1)+" columns");}
            @Override public void onStartTrackingTouch(android.widget.SeekBar b){}
            @Override public void onStopTrackingTouch(android.widget.SeekBar b){}
        });
        height.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(android.widget.SeekBar b,int p,boolean user){heightLabel.setText("Height: "+(p+1)+" rows");}
            @Override public void onStartTrackingTouch(android.widget.SeekBar b){}
            @Override public void onStopTrackingTouch(android.widget.SeekBar b){}
        });
        new AlertDialog.Builder(this).setTitle("Resize widget")
                .setView(panel).setNegativeButton("Cancel",null)
                .setPositiveButton("Apply",(d,w)->{
                    widget.spanX=width.getProgress()+1;widget.spanY=height.getProgress()+1;
                    saveLayout();refreshScreen();
                }).show();
    }

    private void removeWidget(Item widget) {
        home.remove(widget);
        try {widgetHost.deleteAppWidgetId(widget.widgetId());}catch(Exception ignored){}
        saveLayout();refreshScreen();
    }

    private void showSearch() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(18), dp(8), dp(18), dp(14));
        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Search all your apps");
        outer.addView(search, new LinearLayout.LayoutParams(-1, dp(54)));
        ScrollView scroller = new ScrollView(this);
        LinearLayout.LayoutParams scp = new LinearLayout.LayoutParams(-1, dp(340));
        outer.addView(scroller, scp);
        GridLayout results = new GridLayout(this);
        results.setColumnCount(4);
        scroller.addView(results);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(outer)
                .setNegativeButton("Close", null).create();
        int tileWidth = (getResources().getDisplayMetrics().widthPixels - dp(75)) / 4;
        Runnable render = () -> {
            results.removeAllViews();
            String query = search.getText().toString().trim().toLowerCase(Locale.getDefault());
            int found = 0;
            for (String id : installed.keySet()) {
                if (!appName(id).toLowerCase(Locale.getDefault()).contains(query)) continue;
                View tile = buildTile(new Item(id), false, tileWidth);
                liveTiles.remove(tile);
                GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
                lp.width = tileWidth; lp.height = dp(98);
                results.addView(tile, lp);
                tile.setOnLongClickListener(v -> { dialog.dismiss(); openAppInfo(id); return true; });
                tile.setOnClickListener(v -> { dialog.dismiss(); activateApp(tile, id); });
                found++;
                if (found >= 100) break;
            }
        };
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { render.run(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        render.run(); dialog.show();
        search.requestFocus();
        if (dialog.getWindow() != null) dialog.getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE |
                        WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }

    private void showSettings() {
        String[] options = {
                "Home grid: " + columns + " columns × " + rows + " rows",
                "App label font: " + labelFont + " · " + labelSizeSp + " sp",
                "Search bar: " + (showSearchBar ? "On" : "Off"),
                "Add widgets",
                "Reduce motion: " + (reduceMotion ? "On" : "Off"),
                "Set default Home app",
                "Reset app arrangement"
        };
        new AlertDialog.Builder(this).setTitle("Home settings")
                .setItems(options, (dialog, selected) -> {
                    if (selected == 0) showGridSettings();
                    if (selected == 1) { showFontSettings(); }
                    if (selected == 2) {
                        showSearchBar = !showSearchBar;
                        prefs.edit().putBoolean("show_search_bar", showSearchBar).apply();
                        refreshScreen();
                    }
                    if (selected == 3) showWidgetPicker();
                    if (selected == 4) {
                        reduceMotion = !reduceMotion;
                        prefs.edit().putBoolean("reduce_motion", reduceMotion).apply();
                        refreshScreen();
                    }
                    if (selected == 5) openHomeSettings();
                    if (selected == 6) new AlertDialog.Builder(this).setTitle("Reset arrangement?")
                            .setMessage("This puts all apps back in alphabetical order. Your folders and custom positions will be reset.")
                            .setNegativeButton("Cancel", null)
                            .setPositiveButton("Reset", (d, which) -> {
                                for(Item old:new ArrayList<>(home)) if(old.isWidget())
                                    try{widgetHost.deleteAppWidgetId(old.widgetId());}catch(Exception ignored){}
                                home.clear(); dock.clear();
                                for (String id : installed.keySet()) home.add(new Item(id));
                                chooseInitialDock();
                                currentPage = 0;
                                saveLayout(); refreshScreen();
                            }).show();
                }).setPositiveButton("Done", null).show();
    }

    private void showGridSettings() {
        String[] options = {"Columns: " + columns + " (3–6)", "Rows: " + rows + " (3–12)"};
        new AlertDialog.Builder(this).setTitle("Home-screen grid")
                .setItems(options, (dialog, selected) -> {
                    final int minimum = 3;
                    final int maximum = selected == 0 ? 6 : 12;
                    String[] sizes = new String[maximum - minimum + 1];
                    for (int i = minimum; i <= maximum; i++)
                        sizes[i - minimum] = i + (selected == 0 ? " columns" : " rows");
                    new AlertDialog.Builder(this)
                            .setTitle(selected == 0 ? "Choose columns" : "Choose rows")
                            .setSingleChoiceItems(sizes, (selected == 0 ? columns : rows) - minimum,
                                    (d, which) -> {
                                        int count = minimum + which;
                                        if (selected == 0) {
                                            columns = count;
                                            prefs.edit().putInt("columns", columns).apply();
                                        } else {
                                            rows = count;
                                            prefs.edit().putInt("rows", rows).apply();
                                        }
                                        currentPage = 0;
                                        d.dismiss(); refreshScreen();
                                    }).show();
                }).setPositiveButton("Done", null).show();
    }

    private void openHomeSettings() {
        try { startActivity(new Intent(Settings.ACTION_HOME_SETTINGS)); }
        catch (Exception error) { toast("Go to Settings → Apps → Default apps → Home app"); }
    }

    private void showWelcome() {
        if (isFinishing()) return;
        new AlertDialog.Builder(this).setTitle("Welcome to Pixel Home")
                .setMessage("All apps live on home pages; there is no app drawer. Drag one app onto another to make a folder. Long-press an empty area to add real Android widgets or change home settings.")
                .setPositiveButton("Choose as Home app", (dialog, which) -> openHomeSettings())
                .setNegativeButton("Later", null).show();
    }

    private void toast(String value) { Toast.makeText(this, value, Toast.LENGTH_SHORT).show(); }

    private class SnapPages extends HorizontalScrollView {
        private float downX, downY;
        private int downPage;
        SnapPages(Context c) { super(c); }
        void goToPage(int index, boolean smooth) {
            currentPage = Math.max(0, Math.min(index, pageViews.size() - 1));
            int destination = currentPage * getResources().getDisplayMetrics().widthPixels;
            if (smooth && !reduceMotion) smoothScrollTo(destination, 0);
            else scrollTo(destination, 0);
            updateDots();
        }
        @Override public boolean dispatchTouchEvent(MotionEvent event) {
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                downX = event.getX(); downY = event.getY();
                downPage = Math.round(getScrollX() / (float) Math.max(1, getWidth()));
            }
            boolean handled = super.dispatchTouchEvent(event);
            if (action == MotionEvent.ACTION_UP) {
                float dx = event.getX() - downX;
                float dy = event.getY() - downY;
                if (!editing && dy > dp(115) && Math.abs(dx) < dp(55)) {
                    post(MainActivity.this::showSearch);
                } else if (Math.abs(dx) > dp(35)) {
                    int target = downPage + (dx < 0 ? 1 : -1);
                    post(() -> goToPage(target, true));
                }
            }
            return handled;
        }
        @Override public void fling(int velocityX) {
            // Native fling would overshoot multiple pages; the release animation above snaps one page.
        }
        @Override protected void onScrollChanged(int x, int y, int oldX, int oldY) {
            super.onScrollChanged(x, y, oldX, oldY);
            int width = Math.max(1, getResources().getDisplayMetrics().widthPixels);
            int roundedPage = Math.max(0, Math.min(pageViews.size() - 1, Math.round(x / (float) width)));
            if (roundedPage != currentPage) { currentPage = roundedPage; updateDots(); }
            // Pixel-style page motion uses simple horizontal snapping without parallax scaling.
        }
    }

    /** Transparent surface over the actual Android wallpaper. */
    private class BackdropView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float drift;
        BackdropView(Context context) { super(context); }
        void setDrift(float value) { drift = value; invalidate(); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            // Pixel-style launcher uses Android system wallpaper, not custom glowing gradients.
            canvas.drawColor(0x12000000);
        }
        private void orb(Canvas canvas, float x, float y, float radius, int tint) {
            paint.setShader(new RadialGradient(x, y, radius,
                    new int[]{tint, tint & 0x00FFFFFF, 0x00000000},
                    new float[]{0f, .67f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawCircle(x, y, radius, paint);
            paint.setShader(null);
        }
    }
}
