# Pixel Home v4 (no app drawer)

A native Android launcher influenced by Google's Pixel Launcher, with **one intentional difference**: all installed apps stay on swipeable home pages, and there is **no app drawer**.

## What's new in v4

- Pixel-like circular app icons, simple horizontal page movement, system wallpaper, a clean At a Glance date, unboxed dock, and bottom search pill. Removed iPhone-like glass effects, artificial gradients, edit-mode wiggle, and parallax scaling.
- Long-press an app to drag it; drop it **on another app to create a folder**, or **on a folder to add the app**. Drag into a dock position to exchange apps; drag to either page edge to switch after a short hover; drop on blank page space to move there.
- Real Android widgets via **AppWidgetManager/AppWidgetHost**: long-press empty home space or open Home settings → Widgets. Select from installed providers, approve binding/configuration if Android requests it, and use the widget corner control to resize or remove it. Widgets are live and their Android-provided state is kept across app restarts.
- 3×3 mini icon folder previews. Editable home grid (columns 3–6, rows 3–12), a selectable font list with Google Sans Medium 15 sp as default and a 8–24 sp font size option, and a bottom search pill On/Off setting.

## Android support

Min SDK 26 (Android 8.0), target SDK 35. Source is native Java and Android SDK only, no remote code or internet permission required. Some system-protected Pixel Launcher features, such as proprietary Google feed or provider-exclusive widgets, are not available to third-party launchers. Font choices fall back to installed system fonts if their family isn't available. The web `PREVIEW.html` is interactive design illustration; it cannot host actual Android widgets.

## GitHub APK build

The included `.github/workflows/build-apk.yml` compiles this project with JDK 17, Gradle 8.9, and Android SDK 35. For the branchline repository, `.github/workflows/glass-home-apk.yml` unpacks the source archive before running this build.

After installing the APK, choose it in Android Settings → Apps → Default apps → Home app. Before changing launchers, keep your existing home app available as a fallback. New builds on GitHub are debug-signed; depending on signing keys, Android may require uninstalling the previous APK, which can clear this launcher's local layout. **The app has not yet been tested on a physical Pixel device.**
