# Glass Home — Android home-screen launcher

A lightweight **native Java Android launcher** inspired by iOS visual effects and Samsung's Home-screen-only layout. It is **not** an iPhone emulator, nor does it replace Android's system navigation or lock screen.

## Version 1.2 features

- **3×3 folder icon previews**: the first nine apps in a folder appear in a compact 3-column by 3-row miniature grid. Opened folders also use a 3-column grid.
- **User-editable rows and columns**: Settings → Home-screen grid → Columns (3–6) or Rows (3–12). Both settings are saved between launches.
- **Font selector**: default Google Sans Medium, 15sp, with a Note-style list of alternative system fonts. The app shows a system fallback when a device does not have a requested font.
- **Dense grid vertical scrolling**: when there are 8–12 rows, each home page scrolls vertically instead of cutting off icons.
- **Search bar on/off**: Settings → Search bar. Hiding it frees home-screen space; swipe down on the home screen still opens app search.
- **Interactive browser preview**: the ⚙ Settings button now lets you change columns, rows, wallpaper and the search bar, and a sample 3×3 folder can be opened.

## Features

- **No app drawer.** Every installed launchable app is automatically placed on the home pages. Newly installed apps appear automatically; uninstalled apps disappear.
- Horizontal home pages with snap animation, subtle fading/scaling, and page dots.
- Four-app frosted-glass dock. Dock apps can be swapped with home apps.
- Tap an icon to launch it. Long-press an icon to jiggle and drag to rearrange (within a page). While editing, tapping an icon opens an action menu with move and folder options.
- Simple folders: in Edit mode, tap any app → **Create folder with this app**. Drag additional apps onto the folder. Long-press icons inside the folder to move them back out.
- Drag an icon onto another icon to swap positions. Drag to a blank area to move the icon toward the end of that page. For moving across pages, use **Edit → Move to previous/next page**.
- Search from the top search field or swipe down on the home area.
- Three built-in glowing gradient backgrounds, plus a system-wallpaper option.
- Choose 3–6 columns, 3–12 rows, show/hide the search bar, or reduce motion, under **⚙ Settings**.
- Local-only preferences persist grid, dock, folder names, and app positions. No accounts, analytics, advertisements, network access, or special permissions.

## Make this your default launcher

1. Build/install the Android app using one of the methods below.
2. Open **Glass Home**.
3. Tap **Choose as Home app**, or open Android **Settings → Apps → Default apps → Home app → Glass Home**.
4. To return to the original launcher, go back to **Default apps → Home app** and choose the original.

> **Important:** Changing the home app does not delete your old launcher, shortcuts, widgets, data, or apps. Android controls the system Recents gesture and app-opening animation, so those transitions may differ by phone manufacturer. This early version doesn't support Android widgets, icon packs, notification badges, or third-party backups. App organization is local to the device.

## Build with Android Studio (Windows/macOS/Linux)

1. Install current **Android Studio** and Android SDK Platform 35.
2. Extract the project ZIP, then choose **File → Open** and open the **GlassHomeLauncher** folder.
3. Sync Gradle; the project uses Android Gradle Plugin **8.7.3**, JDK **17**, and **Gradle 8.9**. If Studio requests a Gradle distribution, choose Gradle 8.9. Since a prebuilt Gradle Wrapper binary is not bundled, you may need to select a local Gradle installation or generate the normal wrapper first.
4. Connect your Android phone with USB debugging, and choose **Run**. Or choose **Build → Build APK(s)**.
5. Debug APK is `app/build/outputs/apk/debug/app-debug.apk`. Install that APK on your phone.

## Build without Android Studio using GitHub Actions

This project includes `.github/workflows/build-apk.yml`, which builds and provides an unsigned-for-release **debug APK** that Android can install. It is not a Play Store release build. You don't need a local SDK:

1. Create an empty GitHub repository and upload **the contents of the extracted project** (including `.github`).
2. Go to the repository's **Actions → Build Android APK → Run workflow**. Push to `main` also triggers the build.
3. Once the workflow finishes, open the run and download the `GlassHome-debug-apk` artifact. Extract that ZIP to get `app-debug.apk`.
4. Transfer/install the APK on your Android phone (enable installing APKs from that source if Android asks).

## Design preview

Open `PREVIEW.html` in a desktop or mobile browser to try the visual layout. Its icons are illustrative: only the compiled native Android launcher sees and opens your actual installed apps.

## Notes

- Minimum Android 8.0 (API 26), target Android 15 (API 35).
- No runtime permissions requested. Installed app discovery uses `<queries>` for launchable activities, rather than blanket package visibility.
- The glass appearance is translucent and gradient-based; it does **not** blur the system wallpaper pixel-by-pixel.
- The source has been updated, but the app has not been device-tested or APK-built in this environment (Android SDK/build-tools and outbound network access are unavailable). No APK is included in the ZIP.
